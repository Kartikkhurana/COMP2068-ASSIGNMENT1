/**
 * Created by kartik khuurana on 2017-06-02
 */
var express = require('express');
var router = express.Router();

/* GET users listing. */
router.get('/', function(req, res, next) {
    res.render('Project', { title: 'Project' });
});

module.exports = router;
