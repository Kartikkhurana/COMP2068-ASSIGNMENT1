/**
 * Created by kartik khurana on 2017-06-02
 */
var express = require('express');
var router = express.Router();

/* GET users listing. */
router.get('/', function(req, res, next) {
    res.render('Service', { title: 'Service' });
});

module.exports = router;
